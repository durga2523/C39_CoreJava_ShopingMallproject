package com.example.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StoreService {

    @Autowired
    private StoreRepository storeRepository;

    public List<Store> getAllStores() {
        return storeRepository.findAll();
    }

    public Optional<Store> getStoreById(int store_id) {
        return storeRepository.findById(store_id);
    }

    public Store addStore(Store store) {
        return storeRepository.save(store);
    }

    public Store updateStore(int storeId, Store storeDetails) {
        Store store = storeRepository.findById(storeId)
                .orElseThrow(() -> new ResourceNotFoundException("Store not found for this id :: " + storeId));

        store.setName(storeDetails.getName());
        store.setCategory(storeDetails.getCategory());
        store.setContactInfo(storeDetails.getContactInfo());
        store.setLocation(storeDetails.getLocation());
        store.setOperatingHours(storeDetails.getOperatingHours());

        return storeRepository.save(store);
    }

    public void deleteStore(int storeId) {
        Store store = storeRepository.findById(storeId)
                .orElseThrow(() -> new ResourceNotFoundException("Store not found for this id :: " + storeId));

        storeRepository.delete(store);
    }
}
